import { Search, Bell, Menu, Video, User } from "lucide-react";
import { Link, useLocation } from "wouter";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export function Header({ onMenuClick }: { onMenuClick: () => void }) {
  const [search, setSearch] = useState("");
  const [, setLocation] = useLocation();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (search.trim()) {
      setLocation(`/?search=${encodeURIComponent(search)}`);
    }
  };

  return (
    <header className="fixed top-0 left-0 right-0 h-16 bg-background/95 backdrop-blur-md border-b border-border z-50 flex items-center px-4 justify-between gap-4">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" onClick={onMenuClick} className="lg:hidden text-muted-foreground hover:text-foreground">
          <Menu className="h-5 w-5" />
        </Button>
        <Link href="/" className="flex items-center gap-2 group">
          <div className="bg-primary p-1.5 rounded-lg group-hover:shadow-[0_0_15px_rgba(239,68,68,0.5)] transition-all duration-300">
            <Video className="h-5 w-5 text-white fill-current" />
          </div>
          <span className="font-display font-bold text-xl tracking-tight hidden sm:block">Stream<span className="text-primary">Flow</span></span>
        </Link>
      </div>

      <form onSubmit={handleSearch} className="flex-1 max-w-xl mx-auto hidden md:flex relative group">
        <div className="relative w-full">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground group-focus-within:text-primary transition-colors" />
          <Input 
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search videos..." 
            className="pl-10 w-full bg-secondary/50 border-transparent focus-visible:bg-background focus-visible:ring-primary/20 rounded-full transition-all duration-300"
          />
        </div>
      </form>

      <div className="flex items-center gap-2 sm:gap-4">
        <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-foreground rounded-full">
          <Search className="h-5 w-5 md:hidden" />
          <Bell className="h-5 w-5 hidden md:block" />
        </Button>
        <div className="h-8 w-8 rounded-full bg-gradient-to-tr from-primary to-purple-500 p-[2px] cursor-pointer hover:scale-105 transition-transform">
          <div className="h-full w-full rounded-full bg-secondary flex items-center justify-center">
            <User className="h-4 w-4 text-foreground" />
          </div>
        </div>
      </div>
    </header>
  );
}
