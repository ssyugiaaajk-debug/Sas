import { Link } from "wouter";
import { Play } from "lucide-react";
import type { Video } from "@shared/schema";
import { formatDistanceToNow } from "date-fns";
import { motion } from "framer-motion";

export function VideoCard({ video }: { video: Video }) {
  return (
    <Link href={`/watch/${video.id}`} className="group block space-y-3 cursor-pointer">
      {/* Thumbnail Container */}
      <div className="relative aspect-video rounded-xl overflow-hidden bg-muted">
        <img 
          src={video.thumbnailUrl} 
          alt={video.title}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-black/20 group-hover:bg-black/0 transition-colors duration-300" />
        
        {/* Play Button Overlay */}
        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
          <div className="bg-black/50 backdrop-blur-sm p-3 rounded-full">
            <Play className="h-6 w-6 text-white fill-white" />
          </div>
        </div>

        {/* Duration Badge */}
        <div className="absolute bottom-2 right-2 px-1.5 py-0.5 rounded bg-black/80 text-white text-xs font-medium backdrop-blur-sm">
          {video.duration}
        </div>
      </div>

      {/* Info */}
      <div className="flex gap-3">
        <div className="flex-shrink-0">
          <div className="h-9 w-9 rounded-full bg-secondary flex items-center justify-center text-xs font-bold text-muted-foreground">
            {video.title.substring(0, 1).toUpperCase()}
          </div>
        </div>
        <div className="flex-1 min-w-0">
          <h3 className="text-base font-semibold text-foreground leading-tight line-clamp-2 group-hover:text-primary transition-colors">
            {video.title}
          </h3>
          <div className="mt-1 text-sm text-muted-foreground flex flex-col">
            <span>{video.category}</span>
            <div className="flex items-center gap-1">
              <span>{new Intl.NumberFormat('en-US', { notation: "compact" }).format(video.views)} views</span>
              <span className="text-xs">•</span>
              <span>{formatDistanceToNow(new Date(video.createdAt), { addSuffix: true })}</span>
            </div>
          </div>
        </div>
      </div>
    </Link>
  );
}

export function VideoCardSkeleton() {
  return (
    <div className="space-y-3">
      <div className="aspect-video rounded-xl bg-secondary animate-pulse" />
      <div className="flex gap-3">
        <div className="h-9 w-9 rounded-full bg-secondary animate-pulse flex-shrink-0" />
        <div className="flex-1 space-y-2">
          <div className="h-4 w-3/4 bg-secondary animate-pulse rounded" />
          <div className="h-3 w-1/2 bg-secondary animate-pulse rounded" />
        </div>
      </div>
    </div>
  );
}
