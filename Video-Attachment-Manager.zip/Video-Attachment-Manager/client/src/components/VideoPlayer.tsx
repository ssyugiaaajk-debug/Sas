import { useRef, useEffect } from "react";

interface VideoPlayerProps {
  src: string;
  poster?: string;
  autoPlay?: boolean;
}

export function VideoPlayer({ src, poster, autoPlay = false }: VideoPlayerProps) {
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    if (autoPlay && videoRef.current) {
      videoRef.current.play().catch(() => {
        // Autoplay failed interaction needed
        console.log("Autoplay blocked");
      });
    }
  }, [src, autoPlay]);

  return (
    <div className="relative aspect-video bg-black rounded-xl overflow-hidden shadow-2xl">
      <video
        ref={videoRef}
        src={src}
        poster={poster}
        controls
        className="w-full h-full object-contain"
        playsInline
      >
        Your browser does not support the video tag.
      </video>
    </div>
  );
}
