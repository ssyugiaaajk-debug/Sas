import { Home, Compass, Clock, ThumbsUp, Flame, Music2, Gamepad2, Laptop, Shirt } from "lucide-react";
import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";

const CATEGORIES = [
  { icon: Home, label: "Home", href: "/" },
  { icon: Flame, label: "Trending", href: "/?category=trending" },
  { icon: Compass, label: "Explore", href: "/?category=explore" },
  { icon: Music2, label: "Music", href: "/?category=music" },
  { icon: Gamepad2, label: "Gaming", href: "/?category=gaming" },
  { icon: Laptop, label: "Tech", href: "/?category=tech" },
  { icon: Shirt, label: "Lifestyle", href: "/?category=lifestyle" },
];

export function Sidebar({ className, isOpen }: { className?: string, isOpen: boolean }) {
  const [location, setLocation] = useLocation();
  const searchParams = new URLSearchParams(window.location.search);
  const currentCategory = searchParams.get("category");

  const isActive = (href: string) => {
    if (href === "/" && location === "/" && !currentCategory) return true;
    if (href.includes("category")) {
      const category = href.split("=")[1];
      return currentCategory === category;
    }
    return false;
  };

  return (
    <aside className={cn(
      "fixed left-0 top-16 bottom-0 w-64 bg-background border-r border-border p-4 z-40 transition-transform duration-300 ease-in-out lg:translate-x-0",
      isOpen ? "translate-x-0" : "-translate-x-full",
      className
    )}>
      <nav className="space-y-1">
        {CATEGORIES.map((item) => {
          const active = isActive(item.href);
          return (
            <Link 
              key={item.label} 
              href={item.href}
              className={cn(
                "flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all duration-200",
                active 
                  ? "bg-primary text-primary-foreground shadow-lg shadow-primary/25" 
                  : "text-muted-foreground hover:bg-secondary hover:text-foreground"
              )}
            >
              <item.icon className={cn("h-5 w-5", active ? "text-white" : "text-muted-foreground")} />
              {item.label}
            </Link>
          );
        })}
      </nav>

      <div className="mt-8 px-4">
        <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-4">Library</h3>
        <nav className="space-y-1">
          <button className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium text-muted-foreground hover:bg-secondary hover:text-foreground transition-all">
            <Clock className="h-5 w-5" />
            History
          </button>
          <button className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium text-muted-foreground hover:bg-secondary hover:text-foreground transition-all">
            <ThumbsUp className="h-5 w-5" />
            Liked Videos
          </button>
        </nav>
      </div>
    </aside>
  );
}
