import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl, type VideoQueryParams } from "@shared/routes";

export function useVideos(params?: VideoQueryParams) {
  return useQuery({
    queryKey: [api.videos.list.path, params],
    queryFn: async () => {
      let url = api.videos.list.path;
      if (params) {
        const queryParams = new URLSearchParams();
        if (params.search) queryParams.append("search", params.search);
        if (params.category) queryParams.append("category", params.category);
        url += `?${queryParams.toString()}`;
      }
      
      const res = await fetch(url);
      if (!res.ok) throw new Error("Failed to fetch videos");
      return api.videos.list.responses[200].parse(await res.json());
    },
  });
}

export function useVideo(id: number) {
  return useQuery({
    queryKey: [api.videos.get.path, id],
    queryFn: async () => {
      const url = buildUrl(api.videos.get.path, { id });
      const res = await fetch(url);
      if (res.status === 404) return null;
      if (!res.ok) throw new Error("Failed to fetch video");
      return api.videos.get.responses[200].parse(await res.json());
    },
    enabled: !!id,
  });
}

export function useAddView() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (id: number) => {
      const url = buildUrl(api.videos.addView.path, { id });
      const res = await fetch(url, { method: api.videos.addView.method });
      if (!res.ok) throw new Error("Failed to increment views");
      return api.videos.addView.responses[200].parse(await res.json());
    },
    onSuccess: (_, id) => {
      queryClient.invalidateQueries({ queryKey: [api.videos.get.path, id] });
      queryClient.invalidateQueries({ queryKey: [api.videos.list.path] });
    },
  });
}
