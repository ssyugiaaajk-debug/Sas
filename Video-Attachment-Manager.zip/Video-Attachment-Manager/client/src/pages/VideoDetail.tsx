import { useEffect, useState } from "react";
import { useRoute } from "wouter";
import { useVideo, useVideos, useAddView } from "@/hooks/use-videos";
import { Header } from "@/components/Header";
import { VideoPlayer } from "@/components/VideoPlayer";
import { VideoCard, VideoCardSkeleton } from "@/components/VideoCard";
import { formatDistanceToNow } from "date-fns";
import { ThumbsUp, ThumbsDown, Share2, Flag, User } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sidebar } from "@/components/Sidebar";
import { Separator } from "@/components/ui/separator";

export default function VideoDetail() {
  const [, params] = useRoute("/watch/:id");
  const id = params ? parseInt(params.id) : 0;
  
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const { data: video, isLoading: isVideoLoading, error: videoError } = useVideo(id);
  // Get related videos (just fetching list for now, ideally backend has a related endpoint)
  const { data: relatedVideos, isLoading: isRelatedLoading } = useVideos({ category: video?.category });
  
  const { mutate: addView } = useAddView();

  useEffect(() => {
    if (id) {
      // Small timeout to simulate view counting after start
      const timer = setTimeout(() => addView(id), 5000);
      return () => clearTimeout(timer);
    }
  }, [id, addView]);

  if (videoError) return <div className="p-8 text-center text-red-500">Video not found</div>;

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Header onMenuClick={() => setIsSidebarOpen(!isSidebarOpen)} />
      <Sidebar className="z-50" isOpen={isSidebarOpen} />
       {isSidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={() => setIsSidebarOpen(false)}
        />
      )}

      <main className="pt-20 px-4 md:px-8 pb-12 max-w-[1800px] mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {isVideoLoading ? (
               <div className="aspect-video bg-secondary animate-pulse rounded-xl" />
            ) : video ? (
              <div className="space-y-4">
                <VideoPlayer src={video.videoUrl} poster={video.thumbnailUrl} autoPlay />
                
                <div className="space-y-2">
                  <h1 className="text-xl md:text-2xl font-bold font-display">{video.title}</h1>
                  
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                     <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <span>{new Intl.NumberFormat('en-US', { notation: "compact" }).format(video.views)} views</span>
                        <span>•</span>
                        <span>{formatDistanceToNow(new Date(video.createdAt), { addSuffix: true })}</span>
                     </div>

                     <div className="flex items-center gap-2">
                        <Button variant="secondary" className="rounded-full gap-2 hover:bg-secondary/80">
                           <ThumbsUp className="h-4 w-4" /> Like
                        </Button>
                        <Button variant="secondary" className="rounded-full gap-2 hover:bg-secondary/80">
                           <ThumbsDown className="h-4 w-4" />
                        </Button>
                        <Button variant="secondary" className="rounded-full gap-2 hover:bg-secondary/80">
                           <Share2 className="h-4 w-4" /> Share
                        </Button>
                        <Button variant="ghost" size="icon" className="rounded-full">
                           <Flag className="h-4 w-4" />
                        </Button>
                     </div>
                  </div>
                </div>

                <Separator className="bg-border" />

                <div className="bg-secondary/30 rounded-xl p-4 space-y-4">
                   <div className="flex items-center gap-3">
                      <div className="h-10 w-10 rounded-full bg-primary flex items-center justify-center">
                         <User className="h-5 w-5 text-white" />
                      </div>
                      <div>
                         <h3 className="font-semibold text-sm">Channel Name</h3>
                         <p className="text-xs text-muted-foreground">1.2M subscribers</p>
                      </div>
                      <Button className="ml-auto rounded-full font-semibold">Subscribe</Button>
                   </div>
                   <p className="text-sm text-muted-foreground whitespace-pre-wrap pl-14">
                      {video.description}
                   </p>
                </div>
              </div>
            ) : null}
          </div>

          {/* Related Videos Sidebar */}
          <div className="lg:col-span-1">
            <h3 className="text-lg font-bold mb-4 font-display">Related Videos</h3>
            <div className="space-y-4">
              {isRelatedLoading ? (
                Array.from({ length: 5 }).map((_, i) => (
                   <div key={i} className="flex gap-2">
                      <div className="w-40 aspect-video bg-secondary animate-pulse rounded-lg" />
                      <div className="flex-1 space-y-2">
                         <div className="h-3 w-3/4 bg-secondary animate-pulse rounded" />
                         <div className="h-3 w-1/2 bg-secondary animate-pulse rounded" />
                      </div>
                   </div>
                ))
              ) : (
                relatedVideos?.filter(v => v.id !== video?.id).map((video) => (
                  <div key={video.id} className="group relative flex gap-2 cursor-pointer" onClick={() => window.location.href = `/watch/${video.id}`}>
                     <div className="relative w-40 aspect-video rounded-lg overflow-hidden bg-muted flex-shrink-0">
                        <img 
                           src={video.thumbnailUrl} 
                           alt={video.title}
                           className="w-full h-full object-cover"
                        />
                        <div className="absolute bottom-1 right-1 px-1 py-0.5 rounded bg-black/80 text-white text-[10px] font-medium">
                           {video.duration}
                        </div>
                     </div>
                     <div className="flex-1 min-w-0 py-1">
                        <h4 className="text-sm font-semibold line-clamp-2 group-hover:text-primary transition-colors">{video.title}</h4>
                        <div className="text-xs text-muted-foreground mt-1">
                           <p>Channel Name</p>
                           <p>{new Intl.NumberFormat('en-US', { notation: "compact" }).format(video.views)} views • {formatDistanceToNow(new Date(video.createdAt))}</p>
                        </div>
                     </div>
                  </div>
                ))
              )}
            </div>
          </div>

        </div>
      </main>
    </div>
  );
}
