import { useState } from "react";
import { useVideos } from "@/hooks/use-videos";
import { VideoCard, VideoCardSkeleton } from "@/components/VideoCard";
import { Header } from "@/components/Header";
import { Sidebar } from "@/components/Sidebar";
import { useLocation } from "wouter";
import { motion } from "framer-motion";

export default function Home() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const searchParams = new URLSearchParams(window.location.search);
  const category = searchParams.get("category");
  const search = searchParams.get("search");

  const { data: videos, isLoading, error } = useVideos({ 
    category: category || undefined,
    search: search || undefined
  });

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Header onMenuClick={() => setIsSidebarOpen(!isSidebarOpen)} />
      
      <Sidebar isOpen={isSidebarOpen} />
      
      {/* Overlay for mobile sidebar */}
      {isSidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-30 lg:hidden"
          onClick={() => setIsSidebarOpen(false)}
        />
      )}

      <main className="lg:pl-64 pt-20 px-4 md:px-8 pb-12">
        <div className="max-w-7xl mx-auto">
          {search && (
             <div className="mb-6">
                <h1 className="text-2xl font-display font-bold">Search results for "{search}"</h1>
             </div>
          )}

          {category && (
             <div className="mb-6 capitalize">
                <h1 className="text-2xl font-display font-bold">{category} Videos</h1>
             </div>
          )}
          
          {error ? (
            <div className="text-center py-20">
              <h2 className="text-xl font-semibold text-destructive">Something went wrong</h2>
              <p className="text-muted-foreground mt-2">Failed to load videos. Please try again.</p>
            </div>
          ) : isLoading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-y-8 gap-x-6">
              {Array.from({ length: 8 }).map((_, i) => (
                <VideoCardSkeleton key={i} />
              ))}
            </div>
          ) : videos?.length === 0 ? (
             <div className="text-center py-20 flex flex-col items-center">
                <div className="w-16 h-16 bg-secondary rounded-full flex items-center justify-center mb-4">
                  <span className="text-2xl">📹</span>
                </div>
                <h2 className="text-xl font-semibold">No videos found</h2>
                <p className="text-muted-foreground mt-2">Try adjusting your search or category.</p>
             </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-y-8 gap-x-6">
              {videos?.map((video, idx) => (
                <motion.div
                  key={video.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3, delay: idx * 0.05 }}
                >
                  <VideoCard video={video} />
                </motion.div>
              ))}
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
