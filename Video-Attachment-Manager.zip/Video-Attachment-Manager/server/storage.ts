import { db } from "./db";
import { videos, type Video, type InsertVideo, type UpdateVideoRequest } from "@shared/schema";
import { eq, ilike, desc, sql, and } from "drizzle-orm";

export interface IStorage {
  getVideos(query?: { search?: string; category?: string }): Promise<Video[]>;
  getVideo(id: number): Promise<Video | undefined>;
  createVideo(video: InsertVideo): Promise<Video>;
  updateVideo(id: number, updates: UpdateVideoRequest): Promise<Video>;
  incrementViews(id: number): Promise<Video>;
}

export class DatabaseStorage implements IStorage {
  async getVideos(query?: { search?: string; category?: string }): Promise<Video[]> {
    const filters = [];
    
    if (query?.search) {
      filters.push(ilike(videos.title, `%${query.search}%`));
    }
    
    if (query?.category && query.category !== 'All') {
      filters.push(eq(videos.category, query.category));
    }

    return await db.select()
      .from(videos)
      .where(filters.length > 0 ? and(...filters) : undefined)
      .orderBy(desc(videos.createdAt));
  }

  async getVideo(id: number): Promise<Video | undefined> {
    const [video] = await db.select().from(videos).where(eq(videos.id, id));
    return video;
  }

  async createVideo(insertVideo: InsertVideo): Promise<Video> {
    const [video] = await db.insert(videos).values(insertVideo).returning();
    return video;
  }

  async updateVideo(id: number, updates: UpdateVideoRequest): Promise<Video> {
    const [updated] = await db.update(videos)
      .set(updates)
      .where(eq(videos.id, id))
      .returning();
    return updated;
  }

  async incrementViews(id: number): Promise<Video> {
    const [updated] = await db.update(videos)
      .set({ views: sql`${videos.views} + 1` })
      .where(eq(videos.id, id))
      .returning();
    return updated;
  }
}

export const storage = new DatabaseStorage();
