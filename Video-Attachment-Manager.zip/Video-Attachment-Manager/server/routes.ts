import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  app.get(api.videos.list.path, async (req, res) => {
    const query = api.videos.list.input?.parse(req.query);
    const videos = await storage.getVideos(query);
    res.json(videos);
  });

  app.get(api.videos.get.path, async (req, res) => {
    const video = await storage.getVideo(Number(req.params.id));
    if (!video) {
      return res.status(404).json({ message: 'Video not found' });
    }
    res.json(video);
  });

  app.post(api.videos.addView.path, async (req, res) => {
    try {
      const updated = await storage.incrementViews(Number(req.params.id));
      if (!updated) {
        return res.status(404).json({ message: 'Video not found' });
      }
      res.json({ views: updated.views });
    } catch (error) {
      res.status(500).json({ message: 'Internal server error' });
    }
  });

  // Initialize seed data
  seedDatabase();

  return httpServer;
}

async function seedDatabase() {
  const existing = await storage.getVideos();
  if (existing.length > 0) return;

  const sampleVideos = [
    {
      title: "Big Buck Bunny",
      description: "Big Buck Bunny tells the story of a giant rabbit with a heart bigger than himself. When one sunny day three rodents rudely harass him, something snaps... and the bunny ain't no bunny anymore! In the typical cartoon tradition he prepares the nasty rodents a comical revenge.",
      thumbnailUrl: "https://upload.wikimedia.org/wikipedia/commons/thumb/c/c5/Big_buck_bunny_poster_big.jpg/800px-Big_buck_bunny_poster_big.jpg",
      videoUrl: "http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
      duration: "9:56",
      category: "Animation"
    },
    {
      title: "Elephant Dream",
      description: "The first Blender Open Movie from 2006.",
      thumbnailUrl: "https://upload.wikimedia.org/wikipedia/commons/thumb/0/0c/Elephants_Dream_poster_hi.jpg/800px-Elephants_Dream_poster_hi.jpg",
      videoUrl: "http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
      duration: "10:53",
      category: "Sci-Fi"
    },
    {
      title: "For Bigger Blazes",
      description: "HBO GO now works with Chromecast -- the easiest way to enjoy online video on your TV. For when you want to settle into your Iron Throne to watch the latest episodes. For $35.",
      thumbnailUrl: "https://images.unsplash.com/photo-1536240478700-b869070f9279?ixlib=rb-4.0.3&auto=format&fit=crop&w=1600&q=80",
      videoUrl: "http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
      duration: "0:15",
      category: "Tech"
    },
    {
      title: "For Bigger Escapes",
      description: "Introducing Chromecast. The easiest way to enjoy online video and music on your TV—for when Batman's escapes aren't quite big enough. For $35. Learn how to use Chromecast with Google Play Movies and more at google.com/chromecast.",
      thumbnailUrl: "https://images.unsplash.com/photo-1492691527719-9d1e07e534b4?ixlib=rb-4.0.3&auto=format&fit=crop&w=1600&q=80",
      videoUrl: "http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
      duration: "0:15",
      category: "Travel"
    },
    {
      title: "Subaru Outback On Street And Dirt",
      description: "Smoking Tire takes the all-new Subaru Outback to the highest point we can find in hopes our customer-appreciation balloon will fly.",
      thumbnailUrl: "https://images.unsplash.com/photo-1494976388531-d1058494cdd8?ixlib=rb-4.0.3&auto=format&fit=crop&w=1600&q=80",
      videoUrl: "http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/SubaruOutbackOnStreetAndDirt.mp4",
      duration: "9:54",
      category: "Auto"
    }
  ];

  for (const video of sampleVideos) {
    await storage.createVideo(video);
  }
}
